/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.main;

/**
 *
 * @author TestUser123
 */
import java.util.ArrayList;
import java.util.Scanner;

public class Series {
    private ArrayList<seriesModel> seriesList = new ArrayList<>();
    private Scanner sc = new Scanner(System.in);

    // 1. Capture a new series
    public void captureSeries() {
        System.out.print("Enter the series id: ");
        int id = Integer.parseInt(sc.nextLine());

        System.out.print("Enter the series name: ");
        String name = sc.nextLine();

        int age = 0;
        while(true) {
            System.out.print("Enter the series age restriction: ");
            String input = sc.nextLine();
            try {
                age = Integer.parseInt(input);
                if(age < 1 || age > 30) {
                    System.out.println("You have entered a incorrect series age!!!");
                } else {
                    break;
                }
            } catch(NumberFormatException e) {
                System.out.println("You have entered a incorrect series age!!!");
            }
        }

        System.out.print("Enter the number of episodes for " + name + ": ");
        int episodes = Integer.parseInt(sc.nextLine());

        seriesList.add(new seriesModel(id, name, age, episodes));
        System.out.println("Series processed successfully!!!");
    }

    // 2. Search
    public void searchSeries() {
        System.out.print("Enter series name to search: ");
        String searchName = sc.nextLine();
        boolean found = false;
        for (seriesModel s : seriesList) {
            if (s.name.equalsIgnoreCase(searchName)) {
                System.out.println("Found: " + s);
                found = true;
            }
        }
        if(!found) System.out.println("Series not found.");
    }

    // 3. Update Age Restriction
    public void updateAgeRestriction() {
        System.out.print("Enter series ID to update age restriction: ");
        int id = Integer.parseInt(sc.nextLine());
        for (seriesModel s : seriesList) {
            if (s.id == id) {
                int age = 0;
                while(true) {
                    System.out.print("Enter new age restriction: ");
                    String input = sc.nextLine();
                    try {
                        age = Integer.parseInt(input);
                        if(age < 1 || age > 30) {
                            System.out.println("You have entered a incorrect series age!!!");
                        } else {
                            break;
                        }
                    } catch(NumberFormatException e) {
                        System.out.println("You have entered a incorrect series age!!!");
                    }
                }
                s.ageRestriction = age;
                System.out.println("Age restriction updated!");
                return;
            }
        }
        System.out.println("Series ID not found.");
    }

    // 4. Delete
    public void deleteSeries() {
        System.out.print("Enter series ID to delete: ");
        int id = Integer.parseInt(sc.nextLine());
        boolean removed = seriesList.removeIf(s -> s.id == id);
        if(removed) {
            System.out.println("Series deleted.");
        } else {
            System.out.println("Series ID not found.");
        }
    }

    // 5. Report
    public void printSeriesReport() {
        System.out.println("\nSERIES REPORT - 2025");
        if(seriesList.isEmpty()) {
            System.out.println("No series available.");
        } else {
            for (seriesModel s : seriesList) {
                System.out.println(s);
            }
        }
    }
}
