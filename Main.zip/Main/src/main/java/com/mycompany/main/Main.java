/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.main;

/**
 *
 * @author TestUser123
 */
import java.util.Scanner;
public class Main {

    public static void main(String[] args) {
    
        Scanner sc = new Scanner(System.in);
        Series seriesManager = new Series();

        System.out.println("LATEST SERIES - 2025");
        System.out.println("************************************");
        System.out.print("Enter (1) to launch menu or any other key to exit: ");
        String choice = sc.nextLine();

        if (!choice.equals("1")) {
            System.out.println("Exiting application...");
            return;
        }

        int option = 0;
        while(option != 6) {
            System.out.println("\nPlease select one of the following menu items:");
            System.out.println("(1) Capture a new series.");
            System.out.println("(2) Search for a series.");
            System.out.println("(3) Update series age restriction.");
            System.out.println("(4) Delete a series.");
            System.out.println("(5) Print series report - 2025");
            System.out.println("(6) Exit Application.");
            System.out.print("Enter option: ");

           

            if(option == 1) {
                seriesManager.captureSeries();
            } else if(option == 2) {
                seriesManager.searchSeries();
            } else if(option == 3) {
                seriesManager.updateAgeRestriction();
            } else if(option == 4) {
                seriesManager.deleteSeries();
            } else if(option == 5) {
                seriesManager.printSeriesReport();
            } else if(option == 6) {
                System.out.println("Exiting application...");
            } else {
                System.out.println("Invalid option! Choose 1-6.");
            }
        }
    }
}
