/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.main;

/**
 *
 * @author TestUser123
 */
public class seriesModel {
    public int id;
    public String name;
    public int ageRestriction;
    public int episodes;

    public seriesModel(int id, String name, int ageRestriction, int episodes) {
        this.id = id;
        this.name = name;
        this.ageRestriction = ageRestriction;
        this.episodes = episodes;
    }

    
    public String toString() {
        return "ID: " + id + ", Name: " + name + ", Age: " + ageRestriction + ", Episodes: " + episodes;
    }
}

